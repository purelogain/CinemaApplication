/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemaapplication;

/**
 * Any cinema application should extend this interface
 * @author maari
 */
public interface CinemaInterface {
    
    
    public void MovieList ();
    
    public void ShowTimes (int n);
    
    public void Pay (int n);
    
    public void ReservationInformation ();
    
}
