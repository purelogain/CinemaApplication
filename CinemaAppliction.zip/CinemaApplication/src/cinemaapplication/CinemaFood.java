/*
 * To change this license header, choose License Headers in Project Properties.Scanner in = new Scanner(System.in);
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemaapplication;

import java.util.Scanner;

/**
 *
 * @author maari
 */
public class CinemaFood extends CinemaPersonalAccount {
    
         Scanner input = new Scanner (System.in);
         
    public CinemaFood(String name, int age, String city, String email, long accountNumber) {
        super(name, age, city, email, accountNumber);
     
    }

    public CinemaFood() {
    }
    
    
    // kitchen35meList 
    public void kitchen35me() {

        boolean c;
        c = true;
        while (c) {
            System.out.println("\n Welcome in kitchen35me Restorant \n ----------");
            System.out.println("Enter 0 For Drink and 1 For Food : ");
            int k = input.nextInt();
            if (k == 1 || k == 0) {
                if (k==0){
                    DrinkList();
                    c = false;
                }else if (k == 1){
                   FoodList(); 
                   c = false;
                }else{
                c = false;
                }
            } else 
                System.out.println("Sorry , This Is Wrong Choice ! ! !");
        }
    }

   public void FoodList() {
        
        System.out.println("\t Choose what you like from the menu\n");
        System.out.println("___MainMeal____\n");
        System.out.println("1-Chicken french fries      27SR           700  Calories"); 
        System.out.println("2-Pizza                     35SR           950  Calories");      
        System.out.println("3-Hot dog                   22SR           400  Calories");
        System.out.println("4-Taco                      27SR           800  Calories");
        System.out.println("5-Popcorn                   15SR           210  Calories");
        System.out.println("6-Nachos                    35SR           567  Calories");
        System.out.println();
        System.out.println("____Desserts____");
        System.out.println("7-Cookies                   22SR           140  Calories");
        System.out.println("8-Chocolate Cupcake         15SR           308  Calories");
        System.out.println("9-Ice cream                 15SR           410  Calories");
        System.out.println("10-Strawberry cheesecake    35SR           870  Calories");
        int a = 0;
        int sum = 0;
        boolean s= true;
        while(s){  
         int r = input.nextInt();
         if (r==1|r==4){
             a=27; 
         }else if (r==2|r==10| r==6){
             a=35;
         }else if (r==3|r==7){
             a=22;
         }else if (r==5|r==8|r==9){
             a=15;
         }else if (r==0){
             break;
         }else{
           System.out.println("Worng, just enter the number in the list") ; }
           sum=sum+a;
           System.out.println("\tWhat else?\n\tif you don't want anything else, enter \"0\"");  }
           System.out.println("____");
           System.out.println("           CinemaFood ");
           System.out.println("____");
           System.out.println(" Name : "+this.name);  
           System.out.println();
           System.out.println("AccountNumber: "+this.accountNumber);
           System.out.println();
           System.out.println("Total amount : "+sum);
    }
   
   
    public void DrinkList() {
 System.out.println("\t Choose what you like from the menu\n");
        System.out.println("_Cold Drinks\n");
        System.out.println("1-Fizzy Drink               27SR           700  Calories"); 
        System.out.println("2-Lemon Juice               35SR           950  Calories");      
        System.out.println("3-Mango Juice               22SR           400  Calories");
        System.out.println("4-Watermelon Juice          27SR           800  Calories");
        System.out.println("5-Berry Mojito              15SR           210  Calories");
        System.out.println("6-Florida Run Runner        35SR           567  Calories");
        System.out.println();
        System.out.println("Hot Drinks");
        System.out.println("7-Espresso                   22SR           140  Calories");
        System.out.println("8-Tea                        15SR           308  Calories");
        System.out.println("9-Coffee                     15SR           410  Calories");
        System.out.println("10-Late                      35SR           870  Calories");
        int a = 0;
        int sum = 0;
        boolean s= true;
        while(s){  
         int r = input.nextInt();
         if (r==1|r==4){
             a=27; 
         }else if (r==2|r==10| r==6){
             a=35;
         }else if (r==3|r==7){
             a=22;
         }else if (r==5|r==8|r==9){
             a=15;
         }else if (r==0){
             break;
         }else{
           System.out.println("Worng, just enter the number in the list") ; }
           sum=sum+a;
           System.out.println("\tWhat else?\n\tif you don't want anything else, enter \"0\"");  }
           System.out.println("__");
           System.out.println("           CinemaFood ");
           System.out.println("__");
           System.out.println(" Name : "+this.name);  
           System.out.println();
           System.out.println("AccountNumber: "+this.accountNumber);
           System.out.println();
           System.out.println("Total amount : "+sum);
    }

}