/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemaapplication;

import java.util.Objects;



/**
 *
 * @author maari
 */
public abstract class CinemaPersonalAccount {
    
    
    String name ;
    int age ;
    String email;
    long accountNumber;
    String city ;
    /**
     * the first constrictor
     * @param name
     * @param age
     * @param city
     * @param email
     * @param accountNumber 
     */
    public CinemaPersonalAccount(String name, int age,String city, String email, long accountNumber) {
        
        this.name = name;
        this.age = age;
        this.email = email;
        this.accountNumber = accountNumber;
        this.city = city ;
    }
    
    
/**
 * defult constrictor
 */
    public CinemaPersonalAccount() {
    }
    
    
    
    public void infoAccount (){
        
        System.out.println( "                       || PERSONAL ACCOUNT || \n------------------------ hello evry one in FOX CiNEMA \n\n name : " + getName() + "\n age : " + getAge() + "\n city : "+ getCity() + "\n email : " + getEmail()+"\n");
    }

    // the setters and getters methods
    
    /**
     * 
     * @return name
     */
    public String getName() {
        return name;
    }
    /**
     * 
     * @param name 
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * 
     * @return age
     */
    public int getAge() {
        return age;
    }
    /**
     * 
     * @param age 
     */
    public void setAge(int age) {
        this.age = age;
    }
    /**
     * 
     * @return email
     */
    public String getEmail() {
        return email+"@gmail.com ";
    }
    /**
     * 
     * @param email 
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * 
     * @return account number
     */
    public long getAccountNumber() {
        return accountNumber;
    }
    /**
     * 
     * @param accountNumber 
     */
    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }
    /**
     * 
     * @return city
     */
    public String getCity() {
        return city;
    }
    /**
     * 
     * @param city 
     */
    public void setCity(String city) {
        this.city = city;
    }
    

    @Override
    public String toString() {
        
        return  "    || PERSONAL ACCOUNT || \n hello evry one in FOX CiNEMA \n name : " + name + "\n age : " + age + "city : "+ city + "\n email : " + email +"@gmail.com" ;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CinemaPersonalAccount other = (CinemaPersonalAccount) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (this.age != other.age) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (this.accountNumber != other.accountNumber) {
            return false;
        }
        if (!Objects.equals(this.city, other.city)) {
            return false;
        }
        return true;
    }

  
    
    
    
}