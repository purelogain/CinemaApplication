/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemaapplication;

/**
 *
 * @authors 
 */
public class CinemaApplication {

    /**
     * @param args the command line arguments
     */
    
    
    public CinemaApplication() {
    }

    public static void main(String[] args) {
        // name , age ,city , email , Account Number
        
        // Movies a1 = new Movies ("Maarib", 19 ," jeddah", " maaribsulimani", 311123);
        //a1.MovieList();
        Movies a2 = new Movies ("Lama", 19 ," jeddah", " lama1421", 1123789273);
    }
    
}