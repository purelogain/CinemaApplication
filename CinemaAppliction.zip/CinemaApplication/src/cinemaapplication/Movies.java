/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemaapplication;

import java.util.*;

/**
 *
 * @author maari
 */
public class Movies extends CinemaFood implements CinemaInterface  {

  
   Map <String , String> Nmovie = new TreeMap <> ();
   public static List <String> set = new ArrayList <> ();
   
    Scanner input = new Scanner (System.in);

    
 

     Movies(String name, int age, String city, String email, long accountNumber) {
        super(name, age, city, email, accountNumber);
        
        Starting ();
    }

     
    public Movies() {
       
    }

  

    public void Starting (){
        
        System.out.println("                            WELCOME "+name.toUpperCase()+" \n   --------------------------          What you want ? \n  1. MOVIES\n  2. Your personal account \n  3. Cinema food ");
        
        int c = input.nextInt();
        if (c==1){
            MovieList();
        }else if (c==2){
            infoAccount();
        }else{
            kitchen35me();
        }
    }
   
    
    /**
     * method for display list of movies .
     */
     int number;
     int num;
     String seatR ="", seatC ="";
        String [][] info = { 
           
        { " WA'AFAT REGALAH " , " Arabic " , " 120 min " , " Comedy "},
        { " GODZILLA VS KONG " , " English " , " 120 min " , " Action "},
        { " SAS:READ NOTICE " , " English " , " 125 min " , " Action "},
        { " CRISIS " , " English " , " 120 min " , " Thriller "},
        { " STAND BY ME " , " Japanese " , " 95 min " , " Animation "},
        { " TOM & JERRY " , " English " , " 100 min " , " Animation "},
        { " RAYA AND THE LAST DRAGON " , " English " , " 115 min " , " Animation "},
        { " QABL AL-ARBAEEN " , " Arabic " , " 90 min " , " Horror "},
    };
          
      
       String[][] time1 =  { 
           
        { " 02:45 pm " , "  03:30 pm " , "  09:00 pm " , "  11:30 pm "},
        { " 02:50 am " , "  03:05 am " , "  04:00 am " , "  09:00 am "},
        { " 10:00 pm " , "  12:00 am " , "  02:00 am " , "  03:45 am "},
        { " 02:45 pm " , "  03:30 pm " , "  04:00 am " , "  09:00 am "},
        { " 02:50 am " , "  03:05 am " , "  10:00 pm " , "  12:00 am "},
        { " 04:00 am " , "  09:00 am " , "  02:50 am " , "  03:05 am "},
        { " 12:00 am " , "  02:00 am " , "  03:05 am " , "  04:00 am "},
        { " 03:05 am " , "  10:00 pm " , "  04:00 am " , "  09:00 am "},
    };
       
    @Override
    public void MovieList() {
       
        // movies list
        System.out.println("   || WELCOM TO VOX CINEMA ||");
        System.out.println(" pleas choos the movie that you want :");
        System.out.println(" ");
        Nmovie.put(" 1. Arabic  ", "  WA'AFAT REGALAH ");
        Nmovie.put(" 2. English ","  GODZILLA VS KONG ");
        Nmovie.put(" 3. English ","  SAS:READ NOTICE ");
        Nmovie.put(" 4. English ","  CRISIS ");
        Nmovie.put(" 5. Japanese "," STAND BY ME ");
        Nmovie.put(" 6. English ","  TOM & JERRY ");
        Nmovie.put(" 7. English ","  RAYA AND THE LAST DRAGON ");
        Nmovie.put(" 8. Arabic ","   QABL AL-ARBAEEN ");
        
        // print the list
        for ( Map.Entry < String ,String > e : Nmovie.entrySet()){
            System.out.println(e.getKey()+ " "+ e.getValue());
        }
        
         number = input.nextInt();
        ShowTimes(number-1);
    }
    
    /**
     * method for display times of show .
     */
    @Override
    public void ShowTimes(int n) {
        
       // table of times to choose
      String[][] time =  { 
           
        { "1. 02:45 pm " , " 2. 03:30 pm " , " 3. 09:00 pm " , " 4. 11:30 pm "},
        { "1. 02:50 am " , " 2. 03:05 am " , " 3. 04:00 am " , " 4. 09:00 am "},
        { "1. 10:00 pm " , " 2. 12:00 am " , " 3. 02:00 am " , " 4. 03:45 am "},
        { "1. 02:45 pm " , " 2. 03:30 pm " , " 3. 04:00 am " , " 4. 09:00 am "},
        { "1. 02:50 am " , " 2. 03:05 am " , " 3. 10:00 pm " , " 4. 12:00 am "},
        { "1. 04:00 am " , " 2. 09:00 am " , " 3. 02:50 am " , " 4. 03:05 am "},
        { "1. 12:00 am " , " 2. 02:00 am " , " 3. 03:05 am " , " 4. 04:00 am "},
        { "1. 03:05 am " , " 2. 10:00 pm " , " 3. 04:00 am " , " 4. 09:00 am "},
    };
      
      // print information of the movie that user is choose and print 4 diffrint timse
        System.out.println(" ");
        System.out.println(" choose the time or inter 0 to go back ");
        System.out.println(" ");
        System.out.println(info [n][0]+ " "+ info [n][1]+ " "+ info [n][2]+" "+info [n][3]);
        System.out.println(" ");
        System.out.println(time [n][0]+ " "+ time [n][1]+ " "+ time [n][2]+" "+time [n][3]);
        num = input.nextInt();
        if (num == 0){
            MovieList();
        }else{
            Pay(num);
        }
    }
    
    /**
     * method for payment .
     */
    @Override
    public void Pay(int n) {

        // table of seats
        String [][] array = {    
        { " A " , "1" , "2" , "3" , "4" , "5"},
        { " B " , "6" , "7" , "8" , "9" , "10"},
        { " C " , "11" , "12" , "13" , "14" , "15"},
        { " D " , "16" , "17" , "18" , "19" , "20"},
        { " E " , "21" , "22" , "23" , "24" , "25"},
        { " F " , "26" , "27" , "28" , "29" , "30"},
        { " G " , "31" , "32" , "33" , "34" , "35"},
        { " H " , "36" , "37" , "38" , "39" , "40"},
      };
    
        
        // print all the array of seats
         System.out.println(" select number of your seat : ");
         System.out.println(" ");
         for(int i=0 ;i<array.length ; i++){
           for(int j=0 ; j<array[i].length ; j++){
               System.out.print(  array [i][j]+" " ) ;
               
           }
             System.out.println(" ");
    }
         // number of seat that user will select
          String s = input.next();
          
         // put the seat in list array to cheak if the seat is availabe or not
          if (set.isEmpty()== true){
               
               set.add(s);
               
           }else {
               
               while(set.contains(s) == true){
                   System.out.println(" Sorry this seat is reserved select annuther seat :  ");
                    s = input.next();
               }
               set.add(s);
               
           }
          int t = 0;
          int [][] array1 = new int [8][5];
           for( int i=0;i<8 ; i++){
           for(int j=1 ; j<5 ; j++){
               t = Integer.parseInt(array[i][j]);
                array1[i][j]= t;
           }
         } 
         
          // search number of seat 
         int d = Integer.parseInt(s);
          for( int i=0;i<array1.length ; i++){
           for(int j=0 ; j<array1[i].length ; j++){
               
               if (array1[i][j] == d){
                    seatR = array[i][0] ;
                    seatC = array[0][j];
                    break;
               }else{
                  
               }
                
           }
           
        }
           // to pay
         System.out.println(" your seat is "+seatR+seatC);
         
         System.out.println(" ");
         System.out.println("Pleas pay 65 S.R to complet the reservation ");
         System.out.println(" ");
         System.out.println(" Enter 1 to pay from the crdet card that has Account number : "+accountNumber+" \n or 0 to chang the creadet card or 10 to Exit : ");
         int c = input.nextInt();
         System.out.println(" ");
         if (c == 1){
             System.out.println(" Reservation was successful ");
             System.out.println(" ");
             ReservationInformation();
         }else if (c == 0){
             System.out.println(" Enter new Account number : ");
             long c1 = input.nextLong();
             setAccountNumber(c1);
             System.out.println(" Reservation was successful from new credet card with the Account number : "+getAccountNumber());
             ReservationInformation();
         }else{
             System.out.println("\\ YOUR RESERVATION IS CANCELED \\");
         }
                 
    }
   
   
    
    /**
     * method for display Reservate ionInformation .
     */
    @Override
    public void ReservationInformation() {
     
        System.out.println(" ");
        System.out.println("     RESERVATION INFORMATION \n ------------------------------- \n");
        System.out.println("|| "+info[number-1][0]+" || \n "+info[number-1][1]+"  "+info[number-1][2]+"  "+info[number-1][3]+"\n --------------------- \n");
        System.out.println(" VOX CINEMA : "+city+"\n ----------------- \n WHEN : "+time1[number-1][num-1]+" \n ----------------- \n SEAT : "+seatR+seatC+" \n ----------------- \n CARD PAYMENT : 65 S.R \n -------------------- \n");
        System.out.println(" QR icone \n");
        System.out.println("[|=][=]|=[||]-[|=]\n[|=][=]|=[||]-[|=]\n[|=][=]|=[||]-[|=]\n[|=][=]|=[||]-[|=]\n[|=][=]|=[||]-[|=]\n[|=][=]|=[||]-[|=]");
        System.out.println("\n THANK YOU "+name+" ENJOY YOUR MOVIE !\n (don't forget to show QR icon)\n ------------ ");
        
        System.out.println(" \n \n ENTER 1 TO CHOOS YOUR MEAL IN CINEMA FOOD !! or 0 to exit");
        int v =input.nextInt();
        if (v == 1){
          kitchen35me();  
        }else{
      
        }
    }
    
   
    
}
